﻿from __future__ import print_function, absolute_import, division
import yaml
import h5py
import os
import time
import torch
import torch.nn as nn
from torch import optim
from torch.utils.data import DataLoader
from torch.autograd import Variable
import numpy as np
from torch.utils.data.dataloader import DataLoader
import data_utils
import space_angle_velocity
import bone_length_loss
import model_enhance_each_joint
import model_GAN
import torchsnooper
import matplotlib.pyplot as plt
import scipy.io as io
import math


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
config = yaml.load(open('config.yml'), Loader=yaml.FullLoader)

node_num = config['node_num']
input_n = config['input_n']
output_n = config['output_n']
base_path = '/home/lv/MM/H3.6M/motion_prediction_code/code/data'
input_size = config['in_features']
hidden_size = config['hidden_size']
output_size = config['out_features']
lr = config['learning_rate']
batch_size = config['batch_size']
train_save_path = os.path.join(base_path, 'train.npy')
train_save_path = train_save_path.replace("\\", "/")
dataset = np.load(train_save_path, allow_pickle=True)
a = 0.9

move_joint = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19, 21, 22, 25, 26, 27, 29, 30])
use_node = np.array([0, 1, 2, 3, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 20, 21, 22])
right_chain = [12, 15, 16]
# 25node
chain = [[1], [132.95, 442.89, 454.21, 162.77, 75], [132.95, 442.89, 454.21, 162.77, 75],
         [233.58, 257.08, 121.13, 115], [257.08, 151.03, 278.88, 251.73, 100],
         [257.08, 151.03, 278.88, 251.73, 100]]
for x in chain:
    s = sum(x)
    if s == 0:
        continue
    for i in range(len(x)):
        x[i] = (i + 1) * sum(x[i:]) / s

chain = [item for sublist in chain for item in sublist]
nodes_weight = torch.tensor(chain)
nodes_weight = nodes_weight.unsqueeze(1)
nodes_frame_weight = nodes_weight.expand(25, 25)

frame_weight = torch.tensor([3, 2, 1.5, 1.5, 1, 0.5, 0.2, 0.2, 0.1, 0.1,
                             0.06, 0.06, 0.05, 0.05, 0.04, 0.04, 0.03, 0.03, 0.03, 0.02, 0.02,
                             0.02, 0.02, 0.02, 0.02])

for k in right_chain:

    loss_list = []
    loss_ep = []
    for epoch in range(config['train_epoches']):

        for i in range(dataset.shape[0]):
            print("i", i)
            data = dataset[i]

            train_data = data_utils.LPDataset(data, input_n, output_n)
            train_loader = DataLoader(
                dataset=train_data,
                batch_size=config['batch_size'],
                shuffle=True,
                pin_memory=True,
                drop_last=True
            )

            model_x = model_GRU.Generator(input_size, hidden_size, output_size, node_num, batch_size)
            model_y = model_GRU.Generator(input_size, hidden_size, output_size, node_num, batch_size)
            model_z = model_GRU.Generator(input_size, hidden_size, output_size, node_num, batch_size)
            model_v = model_GRU.Generator(input_size, hidden_size, output_size, node_num, batch_size)

            Disc_x = model_GAN.Discriminator()
            Disc_y = model_GAN.Discriminator()
            Disc_z = model_GAN.Discriminator()

            criterion = nn.BCELoss()
            print(">>> total params: {:.2f}M".format(sum(p.numel() for p in model_v.parameters()) / 1000000.0))

            optimizer_x = optim.Adam(model_x.parameters(), lr)
            optimizer_y = optim.Adam(model_y.parameters(), lr)
            optimizer_z = optim.Adam(model_z.parameters(), lr)
            optimizer_v = optim.Adam(model_v.parameters(), lr)

            d_optimizer_x = torch.optim.Adam(Disc_x.parameters(), lr)
            d_optimizer_y = torch.optim.Adam(Disc_y.parameters(), lr)
            d_optimizer_z = torch.optim.Adam(Disc_z.parameters(), lr)

            base_name = "generator_x_" + str(move_joint[k]) + ".pkl"
            if os.path.exists(os.path.join(base_path, base_name)):
                print("exists")
                model_x.load_state_dict(torch.load(os.path.join(base_path,
                                                                'generator_x_' + str(move_joint[k]) + ".pkl")), strict=False)
                model_y.load_state_dict(torch.load(os.path.join(base_path,
                                                                'generator_y_' + str(move_joint[k]) + ".pkl")), strict=False)
                model_z.load_state_dict(torch.load(os.path.join(base_path,
                                                                'generator_z_' + str(move_joint[k]) + ".pkl")), strict=False)
                model_v.load_state_dict(torch.load(os.path.join(base_path,
                                                                'generator_v_' + str(move_joint[k]) + ".pkl")), strict=False)

                Disc_x.load_state_dict(torch.load(os.path.join(base_path,
                                                               'Disc_x_' + str(move_joint[k]) + ".pkl")), strict=False)
                Disc_y.load_state_dict(torch.load(os.path.join(base_path,
                                                               'Disc_y_' + str(move_joint[k]) + ".pkl")), strict=False)
                Disc_z.load_state_dict(torch.load(os.path.join(base_path,
                                                               'Disc_z_' + str(move_joint[k]) + ".pkl")), strict=False)

                for i, data in enumerate(train_loader):
                    print("i:", i)

                    optimizer_x.zero_grad()
                    optimizer_y.zero_grad()
                    optimizer_z.zero_grad()
                    optimizer_v.zero_grad()

                    d_optimizer_x.zero_grad()
                    d_optimizer_y.zero_grad()
                    d_optimizer_z.zero_grad()

                    in_shots, out_shot = data
                    gt_25frame = out_shot[:, :, :, :4]
                    real_label = torch.ones(gt_25frame.size(0))  # 定义真实的图片label为1
                    fake_label = torch.zeros(gt_25frame.size(0))  # 定义假的图片的label为0

                    real_z = torch.rand(gt_25frame.size(0)) / 5
                    real_label = real_label - real_z
                    fake_z = torch.rand(gt_25frame.size(0)) / 5
                    fake_label = fake_label + fake_z

                    input_angle = in_shots[:, 1:, k, :3].unsqueeze(dim=2)
                    input_velocity = in_shots[:, 1:, k, 3].unsqueeze(dim=2).permute(0, 2, 1)
                    target_angle = out_shot[:, :, k, :3].unsqueeze(dim=2)
                    target_velocity = out_shot[:, :, k, 3].unsqueeze(dim=2)


                    # read velocity
                    input_velocity = input_velocity.float()
                    target_velocity = target_velocity.float()

                    # read angle_x
                    input_angle_x = input_angle[:, :, :, 0].permute(0, 2, 1).float()
                    target_angle_x = target_angle[:, :, :, 0].float()

                    # read angle_y
                    input_angle_y = input_angle[:, :, :, 1].permute(0, 2, 1).float()
                    target_angle_y = target_angle[:, :, :, 1].float()

                    # read angle_z
                    input_angle_z = input_angle[:, :, :, 2].permute(0, 2, 1).float()
                    target_angle_z = target_angle[:, :, :, 2].float()

                    # read 3D data
                    input_3d_data = in_shots[:, :, k, 4:]
                    target_3d_data = out_shot[:, :, k, 4:]

                    loss_v = 0
                    loss_x = 0
                    loss_y = 0
                    loss_z = 0


                    move_loss_x = 0.0
                    move_loss_y = 0.0
                    move_loss_z = 0.0
                    move_loss_v = 0.0

                    output_v = model_v(input_velocity).detach()
                    output_v = output_v.view(target_velocity.shape[0], target_velocity.shape[2], output_size)
                    target_velocity_loss = target_velocity.permute(0, 2, 1)
                    loss_v += torch.mean(
                        torch.norm((output_v - target_velocity_loss) * frame_weight, 2, 1))

                    gt_move_loss_v = 0.0
                    for m in range(1, output_size):
                        gap = output_v[:, :, m] - output_v[:, :, m - 1]
                        gt_gap = target_velocity_loss[:, :, m] - target_velocity_loss[:, :, m - 1]
                        gap = abs(gap)
                        gt_gap = abs(gt_gap)
                        move_loss_v += gap
                        gt_move_loss_v += gt_gap
                    move_loss_v = move_loss_v.numpy().mean()
                    gt_move_loss_v = gt_move_loss_v.numpy().mean()
                    move_loss_v = abs(move_loss_v)
                    gt_move_loss_v = abs(gt_move_loss_v)
                    move_loss_v = abs(gt_move_loss_v - move_loss_v)


                    output_x = model_x(input_angle_x).detach()
                    output_x = output_x.view(target_angle_x.shape[0], target_angle_x.shape[2], output_size)
                    target_angle_x_loss = target_angle_x.permute(0, 2, 1)
                    loss_x += torch.mean(
                        torch.norm((output_x - target_angle_x_loss) * frame_weight, 2, 1))

                    gt_move_loss_x = 0.0
                    for m in range(1, output_size):
                        gap = output_x[:, :, m] - output_x[:, :, m - 1]
                        gt_gap = target_angle_x_loss[:, :, m] - target_angle_x_loss[:, :, m - 1]
                        gap = abs(gap)
                        gt_gap = abs(gt_gap)
                        move_loss_x += gap
                        gt_move_loss_x += gt_gap
                    move_loss_x = move_loss_x.numpy().mean()
                    gt_move_loss_x = gt_move_loss_x.numpy().mean()
                    move_loss_x = abs(move_loss_x)
                    gt_move_loss_x = abs(gt_move_loss_x)
                    move_loss_x = abs(gt_move_loss_x - move_loss_x)

                    output_y = model_y(input_angle_y).detach()
                    output_y = output_y.view(target_angle_y.shape[0], target_angle_y.shape[2], output_size)
                    target_angle_y_loss = target_angle_y.permute(0, 2, 1)
                    loss_y += torch.mean(
                        torch.norm((output_y - target_angle_y_loss) * frame_weight, 2, 1))

                    gt_move_loss_y = 0.0
                    for m in range(1, output_size):
                        gap = output_y[:, :, m] - output_y[:, :, m - 1]
                        gt_gap = target_angle_y_loss[:, :, m] - target_angle_y_loss[:, :, m - 1]
                        gap = abs(gap)
                        gt_gap = abs(gt_gap)
                        move_loss_y += gap
                        gt_move_loss_y += gt_gap
                    move_loss_y = move_loss_y.numpy().mean()
                    gt_move_loss_y = gt_move_loss_y.numpy().mean()
                    move_loss_y = abs(move_loss_y)
                    gt_move_loss_y = abs(gt_move_loss_y)
                    move_loss_y = abs(gt_move_loss_y - move_loss_y)

                    output_z = model_z(input_angle_z).detach()
                    output_z = output_z.view(target_angle_z.shape[0], target_angle_z.shape[2], output_size)
                    target_angle_z_loss = target_angle_z.permute(0, 2, 1)
                    loss_z += torch.mean(
                        torch.norm((output_z - target_angle_z_loss) * frame_weight, 2, 1))

                    gt_move_loss_z = 0.0
                    for m in range(1, output_size):
                        gap = output_z[:, :, m] - output_z[:, :, m - 1]
                        gt_gap = target_angle_z_loss[:, :, m] - target_angle_z_loss[:, :, m - 1]
                        gap = abs(gap)
                        gt_gap = abs(gt_gap)
                        move_loss_z += gap
                        gt_move_loss_z += gt_gap
                    move_loss_z = move_loss_z.numpy().mean()
                    gt_move_loss_z = gt_move_loss_z.numpy().mean()
                    move_loss_z = abs(move_loss_z)
                    gt_move_loss_z = abs(gt_move_loss_z)
                    move_loss_z = abs(gt_move_loss_z - move_loss_z)

                    angle_x = output_x.permute(0, 2, 1)
                    angle_y = output_y.permute(0, 2, 1)
                    angle_z = output_z.permute(0, 2, 1)
                    pred_v = output_v.permute(0, 2, 1)

                    total_loss = loss_v + loss_x + loss_y + loss_z

                    # For　d_optimizer_x and optimizer_x
                    # For discriminator
                    real_out_x = Disc_x(target_angle_x)
                    d_loss_real_x = criterion(real_out_x, real_label)  
                    real_scores_x = real_out_x  

                    fake_out_x = Disc_x(angle_x)  
                    d_loss_fake_x = criterion(fake_out_x, fake_label)  
                    fake_scores_x = fake_out_x  

                    d_loss_x = d_loss_real_x + d_loss_fake_x
                    if epoch == 100:
                        d_loss_x.backward()
                        d_optimizer_x.step()

                    # For generator
                    # get fake data
                    D_result_x = Disc_x(angle_x)
                    g_loss_x = criterion(D_result_x, real_label) * 0.0001 + loss_x
                    g_loss_x.backward()
                    nn.utils.clip_grad_norm_(model_x.parameters(), config['gradient_clip'])
                    optimizer_x.step()

                    # For　d_optimizer_y and optimizer_y
                    # For discriminator
                    real_out_y = Disc_y(target_angle_y)
                    d_loss_real_y = criterion(real_out_y, real_label) 
                    real_scores_y = real_out_y  

                    fake_out_y = Disc_y(angle_y)  #
                    d_loss_fake_y = criterion(fake_out_y, fake_label)  
                    fake_scores_y = fake_out_y 
                    d_loss_y = d_loss_real_y + d_loss_fake_y
                    if epoch == 100:
                        d_loss_y.backward()
                        d_optimizer_y.step()

                    # For generator
                    # get fake data
                    D_result_y = Disc_y(angle_y)
                    g_loss_y = criterion(D_result_y, real_label) * 0.0001 + loss_y
                    g_loss_y.backward()
                    nn.utils.clip_grad_norm_(model_y.parameters(), config['gradient_clip'])
                    optimizer_y.step()

                    # For　d_optimizer_z and optimizer_z
                    # For discriminator
                    real_out_z = Disc_z(target_angle_z)
                    d_loss_real_z = criterion(real_out_z, real_label)  
                    real_scores_z = real_out_z  

                    fake_out_z = Disc_z(angle_z)  
                    d_loss_fake_z = criterion(fake_out_z, fake_label)  
                    fake_scores_z = fake_out_z  

                    d_loss_z = d_loss_real_z + d_loss_fake_z
                    if epoch == 100:
                        d_loss_z.backward()
                        d_optimizer_z.step()

                    # For generator
                    # get fake data
                    D_result_z = Disc_z(angle_z)
                    g_loss_z = criterion(D_result_z, real_label) * 0.0001 + loss_z
                    g_loss_z.backward()
                    nn.utils.clip_grad_norm_(model_z.parameters(), config['gradient_clip'])
                    optimizer_z.step()

                    g_loss_v = loss_v
                    g_loss_v.requires_grad_(True)
                    g_loss_v.backward()
                    nn.utils.clip_grad_norm_(model_v.parameters(), config['gradient_clip'])
                    optimizer_v.step()

                    print('Epoch[{}/{}],Step: {}, move_loss_x:{:.6f}, move_loss_y:{:.6f},'
                          ' move_loss_z:{:.6f}, move_loss_v:{:.6f}'.format(epoch,config['train_epoches'], i,
                            move_loss_x, move_loss_y, move_loss_z, move_loss_v))
     
                    print('Epoch[{}/{}],Step: {},d_loss_x:{:.6f},g_loss_x:{:.6f} '
                          'D real x: {:.6f},D fake x: {:.6f}'.format(
                        epoch, config['train_epoches'], i, d_loss_x.data.item(), g_loss_x.data.item(),
                        real_scores_x.data.mean(), fake_scores_x.data.mean()  
                    ))
                    print('Epoch[{}/{}],Step: {},d_loss_y:{:.6f},g_loss_y:{:.6f} '
                          'D real y: {:.6f},D fake y: {:.6f}'.format(
                        epoch, config['train_epoches'], i, d_loss_y.data.item(), g_loss_y.data.item(),
                        real_scores_y.data.mean(), fake_scores_y.data.mean()  
                    ))
                    print('Epoch[{}/{}],Step: {},d_loss_z:{:.6f},g_loss_z:{:.6f} '
                          'D real z: {:.6f},D fake z: {:.6f}'.format(
                        epoch, config['train_epoches'], i, d_loss_z.data.item(), g_loss_z.data.item(),
                        real_scores_z.data.mean(), fake_scores_z.data.mean()  
                    ))

                    print('[epoch %d] [step %d] [loss %.4f]' % (epoch, i, total_loss.item()))

                torch.save(model_x.state_dict(), os.path.join(base_path, 'generator_x_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_y.state_dict(), os.path.join(base_path, 'generator_y_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_z.state_dict(), os.path.join(base_path, 'generator_z_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_v.state_dict(), os.path.join(base_path, 'generator_v_' + str(move_joint[k]) + ".pkl"))

                torch.save(Disc_x.state_dict(), os.path.join(base_path, 'Disc_x_' + str(move_joint[k]) + ".pkl"))
                torch.save(Disc_y.state_dict(), os.path.join(base_path, 'Disc_y_' + str(move_joint[k]) + ".pkl"))
                torch.save(Disc_z.state_dict(), os.path.join(base_path, 'Disc_z_' + str(move_joint[k]) + ".pkl"))

            else:

                for i, data in enumerate(train_loader):
                    print("---------------Two---------------")
                    optimizer_x.zero_grad()
                    optimizer_y.zero_grad()
                    optimizer_z.zero_grad()
                    optimizer_v.zero_grad()

                    d_optimizer_x.zero_grad()
                    d_optimizer_y.zero_grad()
                    d_optimizer_z.zero_grad()

                    in_shots, out_shot = data

                    # input ground truth data of D
                    gt_25frame = out_shot[:, :, :, :4]
                    real_label = torch.ones(gt_25frame.size(0))  
                    fake_label = torch.zeros(gt_25frame.size(0))  

                    real_z = torch.rand(gt_25frame.size(0)) / 5
                    real_label = real_label - real_z
                    fake_z = torch.rand(gt_25frame.size(0)) / 5
                    fake_label = fake_label + fake_z

                    input_angle = in_shots[:, 1:, k, :3].unsqueeze(dim=2)
                    input_velocity = in_shots[:, 1:, k, 3].unsqueeze(dim=2).permute(0, 2, 1)
                    target_angle = out_shot[:, :, k, :3].unsqueeze(dim=2)
                    target_velocity = out_shot[:, :, k, 3].unsqueeze(dim=2)
                    # print("target_velocity: ",target_velocity.size()) # target_velocity:  torch.Size([16, 25, 25])

                    # read velocity
                    input_velocity = input_velocity.float()
                    target_velocity = target_velocity.float()

                    # read angle_x
                    input_angle_x = input_angle[:, :, :, 0].permute(0, 2, 1).float()
                    target_angle_x = target_angle[:, :, :, 0].float()

                    # print('input_angle_x:\n',input_angle_x.shape)
                    # print('target_angle_x:\n',target_angle_x.shape)

                    # read angle_y
                    input_angle_y = input_angle[:, :, :, 1].permute(0, 2, 1).float()
                    target_angle_y = target_angle[:, :, :, 1].float()

                    # read angle_z
                    input_angle_z = input_angle[:, :, :, 2].permute(0, 2, 1).float()
                    target_angle_z = target_angle[:, :, :, 2].float()

                    # read 3D data
                    input_3d_data = in_shots[:, :, k, 4:]
                    target_3d_data = out_shot[:, :, k, 4:]

                    loss_v = 0
                    loss_x = 0
                    loss_y = 0
                    loss_z = 0

                    move_loss_x = 0.0
                    move_loss_y = 0.0
                    move_loss_z = 0.0
                    move_loss_v = 0.0


                    output_v = model_v(input_velocity).detach()
                    output_v = output_v.view(target_velocity.shape[0], target_velocity.shape[2], output_size)
                    target_velocity_loss = target_velocity.permute(0, 2, 1)
                    loss_v += torch.mean(
                        torch.norm((output_v - target_velocity_loss) * frame_weight, 2, 1))

                    gt_move_loss_v = 0.0
                    for m in range(1, output_size):
                        gap = output_v[:, :, m] - output_v[:, :, m - 1]
                        gt_gap = target_velocity_loss[:, :, m] - target_velocity_loss[:, :, m - 1]
                        gap = abs(gap)
                        gt_gap = abs(gt_gap)
                        move_loss_v += gap
                        gt_move_loss_v += gt_gap
                    move_loss_v = move_loss_v.numpy().mean()
                    gt_move_loss_v = gt_move_loss_v.numpy().mean()
                    move_loss_v = abs(move_loss_v)
                    gt_move_loss_v = abs(gt_move_loss_v)
                    print("gt_move_loss_v", gt_move_loss_v)
                    print("move_loss_v", move_loss_v)
                    move_loss_v = abs(gt_move_loss_v - move_loss_v)

                    output_x = model_x(input_angle_x).detach()
                    output_x = output_x.view(target_angle_x.shape[0], target_angle_x.shape[2], output_size)
                    target_angle_x_loss = target_angle_x.permute(0, 2, 1)
                    loss_x += torch.mean(
                        torch.norm((output_x - target_angle_x_loss) * frame_weight, 2, 1))

                    gt_move_loss_x = 0.0
                    for m in range(1, output_size):
                        gap = output_x[:, :, m] - output_x[:, :, m - 1]
                        gt_gap = target_angle_x_loss[:, :, m] - target_angle_x_loss[:, :, m - 1]
                        gap = abs(gap)
                        gt_gap = abs(gt_gap)
                        move_loss_x += gap
                        gt_move_loss_x += gt_gap
                    move_loss_x = move_loss_x.numpy().mean()
                    gt_move_loss_x = gt_move_loss_x.numpy().mean()
                    move_loss_x = abs(move_loss_x)
                    gt_move_loss_x = abs(gt_move_loss_x)
                    move_loss_x = abs(gt_move_loss_x - move_loss_x)

                    output_y = model_y(input_angle_y).detach()
                    output_y = output_y.view(target_angle_y.shape[0], target_angle_y.shape[2], output_size)
                    target_angle_y_loss = target_angle_y.permute(0, 2, 1)
                    loss_y += torch.mean(
                        torch.norm((output_y - target_angle_y_loss) * frame_weight, 2, 1))

                    gt_move_loss_y = 0.0
                    for m in range(1, output_size):
                        gap = output_y[:, :, m] - output_y[:, :, m - 1]
                        gt_gap = target_angle_y_loss[:, :, m] - target_angle_y_loss[:, :, m - 1]
                        gap = abs(gap)
                        gt_gap = abs(gt_gap)
                        move_loss_y += gap
                        gt_move_loss_y += gt_gap
                    move_loss_y = move_loss_y.numpy().mean()
                    gt_move_loss_y = gt_move_loss_y.numpy().mean()
                    move_loss_y = abs(move_loss_y)
                    gt_move_loss_y = abs(gt_move_loss_y)
                    move_loss_y = abs(gt_move_loss_y - move_loss_y)

                    output_z = model_z(input_angle_z).detach()
                    output_z = output_z.view(target_angle_z.shape[0], target_angle_z.shape[2], output_size)
                    target_angle_z_loss = target_angle_z.permute(0, 2, 1)
                    loss_z += torch.mean(
                        torch.norm((output_z - target_angle_z_loss) * frame_weight, 2, 1))

                    gt_move_loss_z = 0.0
                    for m in range(1, output_size):
                        gap = output_z[:, :, m] - output_z[:, :, m - 1]
                        gt_gap = target_angle_z_loss[:, :, m] - target_angle_z_loss[:, :, m - 1]
                        gap = abs(gap)
                        gt_gap = abs(gt_gap)
                        move_loss_z += gap
                        gt_move_loss_z += gt_gap
                    move_loss_z = move_loss_z.numpy().mean()
                    gt_move_loss_z = gt_move_loss_z.numpy().mean()
                    move_loss_z = abs(move_loss_z)
                    gt_move_loss_z = abs(gt_move_loss_z)
                    move_loss_z = abs(gt_move_loss_z - move_loss_z)

                    angle_x = output_x.permute(0, 2, 1)
                    angle_y = output_y.permute(0, 2, 1)
                    angle_z = output_z.permute(0, 2, 1)
                    pred_v = output_v.permute(0, 2, 1)

                    total_loss = loss_v + loss_x + loss_y + loss_z

                    # For　d_optimizer_x and optimizer_x
                    # For discriminator
                    real_out_x = Disc_x(target_angle_x)
                    d_loss_real_x = criterion(real_out_x, real_label)  
                    real_scores_x = real_out_x  

                    fake_out_x = Disc_x(angle_x) 
                    d_loss_fake_x = criterion(fake_out_x, fake_label)  
                    fake_scores_x = fake_out_x  

                    d_loss_x = d_loss_real_x + d_loss_fake_x
                    if epoch == 100:
                        d_loss_x.backward()
                        d_optimizer_x.step()

                    # For generator
                    # get fake data
                    D_result_x = Disc_x(angle_x)
                    g_loss_x = criterion(D_result_x, real_label) * 0.0001 + loss_x
                    g_loss_x.backward()
                    nn.utils.clip_grad_norm_(model_x.parameters(), config['gradient_clip'])
                    optimizer_x.step()

                    # For　d_optimizer_y and optimizer_y
                    # For discriminator
                    real_out_y = Disc_y(target_angle_y)
                    d_loss_real_y = criterion(real_out_y, real_label)  
                    real_scores_y = real_out_y  

                    fake_out_y = Disc_y(angle_y)  
                    d_loss_fake_y = criterion(fake_out_y, fake_label) 
                    fake_scores_y = fake_out_y  

                    d_loss_y = d_loss_real_y + d_loss_fake_y
                    if epoch == 100:
                        d_loss_y.backward()
                        d_optimizer_y.step()

                    # For generator
                    # get fake data
                    D_result_y = Disc_y(angle_y)
                    g_loss_y = criterion(D_result_y, real_label) * 0.0001 + loss_y
                    g_loss_y.backward()
                    nn.utils.clip_grad_norm_(model_y.parameters(), config['gradient_clip'])
                    optimizer_y.step()

                    # For　d_optimizer_z and optimizer_z
                    # For discriminator
                    real_out_z = Disc_z(target_angle_z)
                    d_loss_real_z = criterion(real_out_z, real_label)  
                    real_scores_z = real_out_z 

                    fake_out_z = Disc_z(angle_z)  
                    d_loss_fake_z = criterion(fake_out_z, fake_label) 
                    fake_scores_z = fake_out_z  

                    d_loss_z = d_loss_real_z + d_loss_fake_z
                    if epoch == 100:
                        d_loss_z.backward()
                        d_optimizer_z.step()

                    # For generator
                    # get fake data
                    D_result_z = Disc_z(angle_z)
                    g_loss_z = criterion(D_result_z, real_label) * 0.0001 + loss_z
                    g_loss_z.backward()
                    nn.utils.clip_grad_norm_(model_z.parameters(), config['gradient_clip'])
                    optimizer_z.step()

                    g_loss_v = loss_v
                    g_loss_v.requires_grad_(True)
                    g_loss_v.backward()
                    nn.utils.clip_grad_norm_(model_v.parameters(), config['gradient_clip'])
                    optimizer_v.step()

                    print('Epoch[{}/{}],Step: {}, move_loss_x:{:.6f}, move_loss_y:{:.6f},'
                          ' move_loss_z:{:.6f}, move_loss_v:{:.6f}'.format(epoch, config['train_epoches'], i,
                            move_loss_x, move_loss_y, move_loss_z, move_loss_v))
                  
                    print('Epoch[{}/{}],Step: {},d_loss_x:{:.6f},g_loss_x:{:.6f} '
                          'D real x: {:.6f},D fake x: {:.6f}'.format(
                        epoch, config['train_epoches'], i, d_loss_x.data.item(), g_loss_x.data.item(),
                        real_scores_x.data.mean(), fake_scores_x.data.mean()  
                    ))
                    print('Epoch[{}/{}],Step: {},d_loss_y:{:.6f},g_loss_y:{:.6f} '
                          'D real y: {:.6f},D fake y: {:.6f}'.format(
                        epoch, config['train_epoches'], i, d_loss_y.data.item(), g_loss_y.data.item(),
                        real_scores_y.data.mean(), fake_scores_y.data.mean()  
                    ))
                    print('Epoch[{}/{}],Step: {},d_loss_z:{:.6f},g_loss_z:{:.6f} '
                          'D real z: {:.6f},D fake z: {:.6f}'.format(
                        epoch, config['train_epoches'], i, d_loss_z.data.item(), g_loss_z.data.item(),
                        real_scores_z.data.mean(), fake_scores_z.data.mean()  
                    ))

                    print('[epoch %d] [step %d] [loss %.4f]' % (epoch, i, total_loss.item()))

                    loss_list.append(total_loss)
                    loss_ep.append(i)

                torch.save(model_x.state_dict(), os.path.join(base_path, 'generator_x_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_y.state_dict(), os.path.join(base_path, 'generator_y_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_z.state_dict(), os.path.join(base_path, 'generator_z_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_v.state_dict(), os.path.join(base_path, 'generator_v_' + str(move_joint[k]) + ".pkl"))

                torch.save(Disc_x.state_dict(), os.path.join(base_path, 'Disc_x_' + str(move_joint[k]) + ".pkl"))
                torch.save(Disc_y.state_dict(), os.path.join(base_path, 'Disc_y_' + str(move_joint[k]) + ".pkl"))
                torch.save(Disc_z.state_dict(), os.path.join(base_path, 'Disc_z_' + str(move_joint[k]) + ".pkl"))

                # plt.plot(loss_ep, loss_list)
                # plt.ylabel('loss')
                # plt.xlabel('ep')
                # plt.show()
                # plt.savefig("epls" + str(move_joint[k]))

    torch.save(model_x, os.path.join(base_path, 'generator_x_' + str(move_joint[k]) + ".pkl"))
    torch.save(model_y, os.path.join(base_path, 'generator_y_' + str(move_joint[k]) + ".pkl"))
    torch.save(model_z, os.path.join(base_path, 'generator_z_' + str(move_joint[k]) + ".pkl"))
    torch.save(model_v, os.path.join(base_path, 'generator_v_' + str(move_joint[k]) + ".pkl"))

    torch.save(Disc_x, os.path.join(base_path, 'Disc_x_' + str(move_joint[k]) + ".pkl"))
    torch.save(Disc_y, os.path.join(base_path, 'Disc_y_' + str(move_joint[k]) + ".pkl"))
    torch.save(Disc_z, os.path.join(base_path, 'Disc_z_' + str(move_joint[k]) + ".pkl"))


